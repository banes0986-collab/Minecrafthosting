package tr.tanticrash;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class TAntiCrash extends JavaPlugin implements Listener {

    private final Map<String, Deque<Long>> ipHits = new ConcurrentHashMap<>();
    private final Map<String, AtomicInteger> pingIp = new ConcurrentHashMap<>();
    private final Map<String, Long> blocked = new ConcurrentHashMap<>();
    private final Set<String> trusted = ConcurrentHashMap.newKeySet();
    private final Set<String> whitelist = ConcurrentHashMap.newKeySet();
    private final Set<String> attackIps = ConcurrentHashMap.newKeySet();
    private final Map<String, String> countries = new ConcurrentHashMap<>();
    private final AtomicInteger logins = new AtomicInteger(), pings = new AtomicInteger();
    private final AtomicLong blockedTotal = new AtomicLong(), attackBlocked = new AtomicLong();
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private volatile boolean attacking, licensed;
    private boolean everLicensed;
    private volatile int cur, onlineCache;
    private long attackStart, lastHigh, attackId, attackLogin, attackPing;
    private int peak, tickN;

    private String apiUrl, apiKey, serverName, serverId;
    private int threshold, endAfter, maxLogins, windowSec, blockSec, maxPing;
    private boolean blockNew, fwEnabled;
    private String fwSet;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        load();
        File tf = new File(getDataFolder(), "trusted.txt");
        try { if (tf.exists()) trusted.addAll(Files.readAllLines(tf.toPath(), StandardCharsets.UTF_8)); } catch (IOException ignored) {}
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, this::tick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, this::verify, 20L, 20L * 60);
        Bukkit.getScheduler().runTaskTimer(this, () -> onlineCache = Bukkit.getOnlinePlayers().size(), 20L, 100L);
        getLogger().info("TAntiCrash aktif.");
    }

    @Override
    public void onDisable() { io.shutdown(); }

    private void load() {
        reloadConfig();
        apiUrl = getConfig().getString("api-url", "");
        apiKey = getConfig().getString("api-key", "");
        serverName = getConfig().getString("server-name", "Sunucu");
        serverId = getConfig().getString("server-id", "");
        if (serverId.isEmpty()) {
            serverId = UUID.randomUUID().toString();
            getConfig().set("server-id", serverId);
            saveConfig();
        }
        threshold = getConfig().getInt("detection.attack-threshold", 30);
        endAfter = getConfig().getInt("detection.end-after-seconds", 15);
        maxLogins = getConfig().getInt("limits.max-logins-per-ip", 3);
        windowSec = getConfig().getInt("limits.window-seconds", 10);
        blockSec = getConfig().getInt("limits.block-seconds", 600);
        maxPing = getConfig().getInt("limits.max-pings-per-ip-per-second", 20);
        blockNew = getConfig().getBoolean("limits.attack-mode-block-new-ips", true);
        fwEnabled = getConfig().getBoolean("firewall.enabled", false);
        fwSet = getConfig().getString("firewall.set-name", "tanticrash");
        whitelist.clear();
        whitelist.addAll(getConfig().getStringList("whitelist-ips"));
    }

    private String msg(String key) {
        return ChatColor.translateAlternateColorCodes('&', getConfig().getString("messages." + key, ""));
    }

    // ---------------- Olaylar ----------------

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        if (!licensed) return;
        String ip = e.getAddress().getHostAddress();
        if (whitelist.contains(ip)) return;
        logins.incrementAndGet();
        long now = System.currentTimeMillis();

        Long until = blocked.get(ip);
        if (until != null) {
            if (until > now) { deny(e, ip, "kick"); return; }
            blocked.remove(ip);
        }

        Deque<Long> d = ipHits.computeIfAbsent(ip, k -> new ConcurrentLinkedDeque<>());
        d.addLast(now);
        long win = windowSec * 1000L;
        Long f;
        while ((f = d.peekFirst()) != null && now - f > win) d.pollFirst();
        if (d.size() > maxLogins) { block(ip); deny(e, ip, "kick"); return; }

        if (attacking && blockNew && !trusted.contains(ip)) deny(e, ip, "attack-kick");
    }

    private void deny(AsyncPlayerPreLoginEvent e, String ip, String key) {
        e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, msg(key));
        blockedTotal.incrementAndGet();
        if (attacking) attackBlocked.incrementAndGet();
        if (attackIps.size() < 5000) attackIps.add(ip);
    }

    @EventHandler
    public void onPing(ServerListPingEvent e) {
        if (!licensed) return;
        String ip = e.getAddress().getHostAddress();
        if (whitelist.contains(ip)) return;
        pings.incrementAndGet();
        pingIp.computeIfAbsent(ip, k -> new AtomicInteger()).incrementAndGet();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        final Player jp = e.getPlayer();
        if (!licensed && jp.hasPermission("tanticrash.admin")) {
            Bukkit.getScheduler().runTaskLater(this, () -> { if (jp.isOnline()) jp.sendMessage(ChatColor.RED + "[TAntiCrash] Lisans anahtari bagli degil, koruma KAPALI. config.yml -> api-key"); }, 40L);
        }
        if (e.getPlayer().getAddress() == null) return;
        final String ip = e.getPlayer().getAddress().getAddress().getHostAddress();
        if (trusted.add(ip)) {
            io.submit(() -> {
                try (FileWriter w = new FileWriter(new File(getDataFolder(), "trusted.txt"), true)) { w.write(ip + "\n"); }
                catch (IOException ignored) {}
            });
        }
    }

    private void block(final String ip) {
        blocked.put(ip, System.currentTimeMillis() + blockSec * 1000L);
        if (fwEnabled && ip.matches("\\d{1,3}(\\.\\d{1,3}){3}")) {
            io.submit(() -> {
                try {
                    new ProcessBuilder("ipset", "add", fwSet, ip, "timeout", String.valueOf(blockSec), "-exist")
                            .redirectErrorStream(true).start().waitFor(5, TimeUnit.SECONDS);
                } catch (Exception ex) { getLogger().warning("ipset hatasi: " + ex.getMessage()); }
            });
        }
    }

    // ---------------- Saniyelik tespit ----------------

    private void tick() {
        if (!licensed) { logins.set(0); pings.set(0); pingIp.clear(); return; }
        int l = logins.getAndSet(0), p = pings.getAndSet(0);
        for (Map.Entry<String, AtomicInteger> en : pingIp.entrySet()) {
            if (en.getValue().get() > maxPing) {
                block(en.getKey());
                if (attackIps.size() < 5000) attackIps.add(en.getKey());
            }
        }
        pingIp.clear();

        int total = l + p;
        cur = total;
        long now = System.currentTimeMillis();

        if (total >= threshold) {
            lastHigh = now;
            if (!attacking) {
                attacking = true;
                attackStart = now; attackId = now; peak = 0;
                attackLogin = 0; attackPing = 0;
                attackBlocked.set(0); attackIps.clear();
                alert(msg("attack-start").replace("%type%", type()).replace("%cps%", String.valueOf(total)));
            }
            if (total > peak) peak = total;
            attackLogin += l; attackPing += p;
            if (tickN % 2 == 0) report("attack_update");
        } else if (attacking) {
            if (now - lastHigh > endAfter * 1000L) {
                report("attack_end");
                alert(msg("attack-end").replace("%duration%", fmt((now - attackStart) / 1000))
                        .replace("%peak%", String.valueOf(peak)).replace("%blocked%", String.valueOf(attackBlocked.get())));
                attacking = false;
            } else if (tickN % 2 == 0) report("attack_update");
        }

        tickN++;
        if (tickN % 30 == 0) report("heartbeat");
        if (tickN % 30 == 0) cleanup(now);
    }

    private String type() { return attackPing > attackLogin ? "PING_FLOOD" : "LOGIN_FLOOD"; }

    private String fmt(long s) { return s >= 60 ? (s / 60) + "dk " + (s % 60) + "sn" : s + "sn"; }

    private void cleanup(long now) {
        long win = windowSec * 1000L;
        for (Map.Entry<String, Deque<Long>> en : ipHits.entrySet()) {
            Long last = en.getValue().peekLast();
            if (last == null || now - last > win) ipHits.remove(en.getKey());
        }
        for (Map.Entry<String, Long> en : blocked.entrySet()) if (en.getValue() < now) blocked.remove(en.getKey());
    }

    private void alert(final String text) {
        getLogger().warning(ChatColor.stripColor(text));
        Bukkit.getScheduler().runTask(this, () -> {
            for (Player pl : Bukkit.getOnlinePlayers()) if (pl.hasPermission("tanticrash.alert")) pl.sendMessage(text);
        });
    }

    // ---------------- Site raporu ----------------

    private void report(final String event) {
        if (apiUrl == null || apiUrl.isEmpty() || apiKey == null || apiKey.isEmpty()) return;
        final boolean isAttack = event.startsWith("attack");
        final long id = attackId, start = attackStart;
        final long dur = (System.currentTimeMillis() - attackStart) / 1000;
        final int pk = peak, c = cur, online = onlineCache;
        final long bl = attackBlocked.get(), total = blockedTotal.get();
        final String tp = type();
        final List<String> ips = new ArrayList<>();
        if (isAttack) for (String ip : attackIps) { ips.add(ip); if (ips.size() >= 10) break; }

        io.submit(() -> {
            StringBuilder sb = new StringBuilder("{");
            sb.append("\"event\":\"").append(event).append("\",");
            sb.append("\"serverId\":\"").append(esc(serverId)).append("\",");
            sb.append("\"serverName\":\"").append(esc(serverName)).append("\",");
            sb.append("\"version\":\"").append(esc(Bukkit.getBukkitVersion())).append("\",");
            sb.append("\"online\":").append(online).append(",");
            sb.append("\"totalBlocked\":").append(total);
            if (isAttack) {
                sb.append(",\"attack\":{\"id\":").append(id).append(",\"type\":\"").append(tp)
                  .append("\",\"startedAt\":").append(start).append(",\"durationSec\":").append(dur)
                  .append(",\"peakPerSec\":").append(pk).append(",\"currentPerSec\":").append(c)
                  .append(",\"blocked\":").append(bl).append(",\"sources\":[");
                for (int i = 0; i < ips.size(); i++) {
                    if (i > 0) sb.append(",");
                    sb.append("{\"ip\":\"").append(esc(ips.get(i))).append("\",\"country\":\"")
                      .append(esc(country(ips.get(i)))).append("\"}");
                }
                sb.append("]}");
            }
            sb.append("}");
            post(sb.toString());
        });
    }

    private void post(String body) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(apiUrl).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(4000); c.setReadTimeout(4000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("X-Api-Key", apiKey);
            try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
            c.getResponseCode();
            c.disconnect();
        } catch (Exception ignored) {}
    }

    private String country(String ip) {
        String cached = countries.get(ip);
        if (cached != null) return cached;
        String r = "Bilinmiyor";
        if (ip.startsWith("127.") || ip.startsWith("10.") || ip.startsWith("192.168.")) r = "Yerel";
        else {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL("http://ip-api.com/line/" + ip + "?fields=country").openConnection();
                c.setConnectTimeout(3000); c.setReadTimeout(3000);
                try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line = br.readLine();
                    if (line != null && !line.trim().isEmpty()) r = line.trim();
                }
            } catch (Exception ignored) {}
        }
        countries.put(ip, r);
        return r;
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
    }

    // ---------------- Lisans ----------------

    private void verify() {
        if (apiKey == null || apiKey.trim().isEmpty() || apiUrl == null || apiUrl.isEmpty()) {
            setLicensed(false, "api-key bos. Siteden anahtar alip config.yml'ye yazin.");
            return;
        }
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(apiUrl.replaceAll("/api/report/?$", "/api/verify")).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("X-Api-Key", apiKey.trim());
            String body = "{\"serverId\":\"" + esc(serverId) + "\",\"serverName\":\"" + esc(serverName)
                    + "\",\"version\":\"" + esc(Bukkit.getBukkitVersion()) + "\"}";
            try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
            int code = c.getResponseCode();
            InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
            StringBuilder sb = new StringBuilder();
            if (is != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String ln; while ((ln = br.readLine()) != null) sb.append(ln);
            }
            c.disconnect();
            if (code == 200 && sb.indexOf("\"ok\":true") >= 0) setLicensed(true, null);
            else if (code == 401) setLicensed(false, "Gecersiz anahtar.");
            else if (code == 403) setLicensed(false, "Bu anahtarin sunucu limiti dolu. Panelden eski sunucuyu silin.");
        } catch (Exception ex) {
            if (!everLicensed) getLogger().warning("Lisans sunucusuna ulasilamadi, tekrar denenecek.");
        }
    }

    private void setLicensed(boolean ok, String why) {
        if (ok) everLicensed = true;
        if (licensed != ok) {
            licensed = ok;
            if (ok) getLogger().info("Lisans dogrulandi, koruma AKTIF.");
            else getLogger().severe("Koruma KAPALI: " + why);
        } else if (!ok) getLogger().warning("Koruma KAPALI: " + why);
    }

    // ---------------- Komut ----------------

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("status")) {
            s.sendMessage(ChatColor.GOLD + "[TAntiCrash] " + ChatColor.WHITE + "Lisans: " + (licensed ? ChatColor.GREEN + "AKTIF" : ChatColor.RED + "YOK/GECERSIZ") + ChatColor.WHITE + " | Durum: "
                    + (attacking ? ChatColor.RED + "SALDIRI" : ChatColor.GREEN + "Normal")
                    + ChatColor.WHITE + " | Anlik: " + cur + "/sn | Engellenen toplam: " + blockedTotal.get()
                    + " | Aktif engel: " + blocked.size());
        } else if (a[0].equalsIgnoreCase("reload")) {
            load();
            io.submit(this::verify);
            s.sendMessage(ChatColor.GREEN + "Yeniden yuklendi, anahtar tekrar dogrulaniyor.");
        } else if (a[0].equalsIgnoreCase("unblock") && a.length > 1) {
            blocked.remove(a[1]); ipHits.remove(a[1]);
            s.sendMessage(ChatColor.GREEN + a[1] + " engeli kaldirildi.");
        } else s.sendMessage(ChatColor.RED + "/tac <status|reload|unblock ip>");
        return true;
    }
}
